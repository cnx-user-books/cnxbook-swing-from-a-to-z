//Note, for some reason I had to replace pack with setSize after release of v1.4

/*File Swing20.java
Rev 8/14/00
Copyright 2000, R.G.Baldwin

Illustrates use of invisible fixed-width and
elastic spacers to control the separation
between components.  In order to see the
effect of the elastic spacers, you must
manually resize the JFrame object to make
it larger and smaller.

Also demonstrates that BoxLayout can be used
with containers other than Box.

Tested using JDK 1.2.2 under WinNT 4.0 WkStn
********************************************/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class Swing20 extends JFrame{

  public static void main(String args[]) {
      new Swing20();
  }//end main()
  //---------------------------------------//

  //The following three methods create and
  // return invisible spacer objects.

  //Creates and returns a fixed spacer
  Box.Filler myFixedSpacer(int x, int y){
    return new Box.Filler(
      new Dimension(x,y),
      new Dimension(x,y),
      new Dimension(x,y));
  }//end myFixedSpacer()

  //Creates and returns an elastic spacer
  Box.Filler myElasticSpacer(int x, int y){
    return new Box.Filler(
      new Dimension(0,0),
      new Dimension(0,0),
      new Dimension(x,y));
  }//end myElasticSpacer()

  //Creates and returns an elastic spacer.
  // Another approach.
  JLabel combinationSpacer(
        int xmin,int ymin,int xmax,int ymax){
    //xmax should never be less than xmin
    //ymax should never be less than ymin
    int tempX = (xmax < xmin)?xmin:xmax;
    int tempY = (ymax < ymin)?ymin:ymax;

    JLabel temp = new JLabel();
    temp.setMinimumSize(
                   new Dimension(xmin,ymin));
    temp.setPreferredSize(
                   new Dimension(xmin,ymin));
    temp.setMaximumSize(
                   new Dimension(tempX,tempY));
    return temp;
  }//end combinationSpacer

  Swing20(){//constructor

    //Just for fun, instantiate a new
    // JButton object and use it as a
    // container.  Set its layout manager
    // to BoxLayout.
    JButton aBut = new JButton();
    aBut.setLayout(
       new BoxLayout(aBut,BoxLayout.X_AXIS));

    //Add the JButton to the contentPane
    getContentPane().add(aBut);

    //Instantiate three JButton objects,
    // make them green.
    JButton but1 = new JButton("b1");
    but1.setBackground(Color.green);

    JButton but2 = new JButton("b2");
    but2.setBackground(Color.green);

    JButton but3 = new JButton("b3");
    but3.setBackground(Color.green);

    //Instantiate two JLabel objects.Color
    // them yellow.
    JLabel lab1 = new JLabel("L1");
    lab1.setBackground(Color.yellow);
    lab1.setOpaque(true);

    JLabel lab2 = new JLabel("L2");
    lab2.setBackground(Color.yellow);
    lab2.setOpaque(true);

    //Add the buttons and the labels to the
    // Box.  Insert spacers between them.
    aBut.add(but1);
    aBut.add(myFixedSpacer(3,0));
    aBut.add(lab1);
    aBut.add(myFixedSpacer(4,0));
    aBut.add(myElasticSpacer(6,0));
    aBut.add(but2);
    aBut.add(myElasticSpacer(12,0));
    aBut.add(myFixedSpacer(5,0));
    aBut.add(lab2);
    aBut.add(combinationSpacer(6,0,24,0));
    aBut.add(but3);

    setTitle("Copyright 2000, R.G.Baldwin");

    //Set the look and feel.
    // First establish the string constants
    String metal =
      "com.sun.java.swing.plaf.metal." +
      "MetalLookAndFeel";
    String motif =
      "com.sun.java.swing.plaf.motif." +
      "MotifLookAndFeel";
    String windows =
      "com.sun.java.swing.plaf.windows." +
      "WindowsLookAndFeel";
    //Set the Look and Feel by enabling one
    // of these
    //String plafClassName = motif;
    //String plafClassName = metal;
    String plafClassName = windows;
    try{
      UIManager.setLookAndFeel(
                              plafClassName);
    }catch(Exception ex){
                     System.out.println(ex);}

    //Cause the L&F to become visible.
    SwingUtilities.
                 updateComponentTreeUI(this);

    //Pack the JFrame down around the
    // components
//    pack();
setSize(300,100);
    setVisible(true);

    //.....................................//
    //Anonymous inner terminator class
    this.addWindowListener(
      new WindowAdapter(){
        public void windowClosing(
                              WindowEvent e){
          System.exit(0);
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
    //.....................................//

  }//end constructor

}//end class Swing20