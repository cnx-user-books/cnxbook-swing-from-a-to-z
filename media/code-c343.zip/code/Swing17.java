/*File Swing17.java
Copyright 2000, R.G.Baldwin
Rev 8/11/00

Illustrates the use of minimum, preferred, 
and maximum sizes.

Three JLabel components are placed in a
horizontal line in a Box layout in a JFrame.
The components are separated from each other
and from the end of the frame by struts.  
Each, strut is ten pixels wide.

The left-most component has its preferred
width set to 1.1 times the default preferred
width. The minimum and maximum sizes for this
component are fixed at the preferred size.
Therefore, its size doesn't change when the
user resizes the JFrame.

The two right-most components have their
minimum widths set to 0.6 times the preferred
width of the left-most component.  Their
maximum widths are set to 1.2 times the 
preferred width of the left-most component.

Manually expand the size of the JFrame to see
that the widths of the two right-most 
components increase to their maximum sizes
and then don't increase any further after 
that.

Manually decrease the size of the JFrame to 
see that the two right-most components 
decrease in width until they reach their
minimum size and then don't decrease in size
any further.  Beyond this point, the right-
most component gets clipped by the edge of
the JFrame when the JFrame is no longer large
enough to accommodate all three components at
their minimum sizes.  

When the right-most component disappears, the
middle component gets clipped. The space 
between the components defined by the struts 
does not decrease.

Tested using JDK 1.2.2 under WinNT 4.0 WkStn
********************************************/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class Swing17 extends JFrame{

  //---------------------------------------//  

  public static void main(String args[]) {
      new Swing17();
  }//end main()
  //---------------------------------------//
  
  Swing17(){//constructor

    //Instantiate a new horizontal Box
    // object.
    Box aBox = Box.createHorizontalBox();

    //Add the Box to the contentPane
    getContentPane().add(aBox);
    
    //Instantiate three JLabel objects,
    // make them green.
    JLabel component1 = 
                    new JLabel("component1");
    component1.setOpaque(true);
    component1.setBackground(Color.green);
    
    JLabel component2 = 
                    new JLabel("component2");
    component2.setBackground(Color.green);
    component2.setOpaque(true);
        
    JLabel component3 = 
                    new JLabel("component3");
    component3.setBackground(Color.green);
    component3.setOpaque(true);
    
    //Get and modify the preferred size of
    // component1
    Dimension preferredSize = 
               component1.getPreferredSize();
    preferredSize.width = 
              (int)(preferredSize.width*1.1);
    component1.setPreferredSize(
                              preferredSize);
    
    //Calculate minimum and maximum sizes
    // based on preferred size of component1.
    Dimension minSize = new Dimension();
    minSize.width = 
              (int)(preferredSize.width*0.6);
    minSize.height = preferredSize.height;

    Dimension maxSize = new Dimension();
    maxSize.width = 
              (int)(preferredSize.width*1.2);
    maxSize.height = preferredSize.height;
    
    //Set minimum and maximum sizes for all
    // three components.  Cause all three to
    // be the same for component1
    component1.setMinimumSize(preferredSize);
    component2.setMinimumSize(minSize);
    component3.setMinimumSize(minSize);
    
    component1.setMaximumSize(preferredSize);
    component2.setMaximumSize(maxSize);
    component3.setMaximumSize(maxSize);
        
    //Add the components to the Box. Insert
    // horizontal struts between the
    // components to control the minimum
    // spacing between them.
    aBox.add(Box.createHorizontalStrut(10));
    aBox.add(component1);
    aBox.add(Box.createHorizontalStrut(10));
    aBox.add(component2);
    aBox.add(Box.createHorizontalStrut(10));
    aBox.add(component3);
    aBox.add(Box.createHorizontalStrut(10));

    setTitle("Copyright 2000, R.G.Baldwin");
    //Pack the JFrame down around the 
    // components
    pack();
    setVisible(true);
    
    //.....................................//
    //Anonymous inner terminator class
    this.addWindowListener(
      new WindowAdapter(){
        public void windowClosing(
                              WindowEvent e){
          System.exit(0);
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
    //.....................................//

  }//end constructor
  
}//end class Swing17