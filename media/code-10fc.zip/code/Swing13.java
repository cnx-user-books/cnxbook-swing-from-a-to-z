/*File Swing13
Rev 3/28/00
Copyright 2000, R.G.Baldwin

Illustrates the border property.  This
program creates and displays several
different border types surrounding a
JLabel object.

Tested using JDK 1.2.2 under WinNT 4.0 WkStn
********************************************/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class Swing13 extends JFrame{

  //---------------------------------------//  

  public static void main(String args[]) {
      new Swing13();
  }//end main()
  //---------------------------------------//
  
  //The purpose of this method is to create
  // and return an opaque pink JLabel with
  // a border.  The text content of the 
  // lable is provided as the first
  // parameter.  The border type is provided
  // as the second parameter.  When the
  // label is displayed, the left and top
  // insets are displayed following the 
  // text content of the label.
  JLabel makeLabel(
           String content,Border borderType){
      
    JLabel label = new JLabel();
    label.setBorder(borderType);
    label.setOpaque(true);
    label.setBackground(Color.pink);

    label.setText(content + "," 
    +label.getInsets().left + ","
    +label.getInsets().top);
      
    return label;
      
  }//end makeLabel()
  //---------------------------------------//
  
  Swing13(){//constructor
    
    getContentPane().setLayout(
                           new FlowLayout());

    getContentPane().add(makeLabel(
         "EtchedBorder",new EtchedBorder()));
    getContentPane().add(makeLabel(
        "BevelBorder RAISED",new BevelBorder(
                       BevelBorder.RAISED)));
    getContentPane().add(makeLabel(
       "BevelBorder LOWERED",new BevelBorder(
                      BevelBorder.LOWERED)));
    getContentPane().add(makeLabel(
         "EmptyBorder",new EmptyBorder(
                                  5,5,5,5)));
    getContentPane().add(makeLabel(
      "Compound, Empty + BevelBorder RAISED",
      new CompoundBorder(new BevelBorder(
      BevelBorder.RAISED),new EmptyBorder(
                                 5,5,5,5))));
    getContentPane().add(makeLabel(
     "Compound, Empty + BevelBorder LOWERED",
     new CompoundBorder(new BevelBorder(
     BevelBorder.LOWERED),new EmptyBorder(
                                 5,5,5,5))));
    
    getContentPane().add(makeLabel(
      "Compound, Empty + SoftBevelBorder " +
      "RAISED",
      new CompoundBorder(new SoftBevelBorder(
      SoftBevelBorder.RAISED),new EmptyBorder(
                                 5,5,5,5))));
    getContentPane().add(makeLabel(
      "Compound, Empty + SoftBevelBorder " +
      "LOWERED",
      new CompoundBorder(new SoftBevelBorder(
      SoftBevelBorder.LOWERED),new EmptyBorder(
                                 5,5,5,5))));
    getContentPane().add(makeLabel(
      "Compound, Empty + LineBorder",
      new CompoundBorder(new LineBorder(
      Color.blue,5),new EmptyBorder(
                                 5,5,5,5))));
    getContentPane().add(makeLabel(
      "Compound, Empty + MatteBorder Image",
      new CompoundBorder(new MatteBorder(
      19,19,19,19,new ImageIcon(
      "blue-ball.gif")),new EmptyBorder(
                                 5,5,5,5))));
                                 
    getContentPane().add(makeLabel(
      "Compound, Empty + MatteBorder Color",
      new CompoundBorder(new MatteBorder(
               19,19,19,19,Color.blue),
                 new EmptyBorder(5,5,5,5))));
                                 
                                 
    getContentPane().add(makeLabel(
      "Compound, Empty + TitledBorder",
      new CompoundBorder(new TitledBorder(
        "Title"),new EmptyBorder(5,5,5,5))));

    setTitle("Copyright 2000, R.G.Baldwin");
    setSize(329,500);
    setVisible(true);
    
    //.....................................//
    //Anonymous inner terminator class
    this.addWindowListener(
      new WindowAdapter(){
        public void windowClosing(
                              WindowEvent e){
          System.exit(0);
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
    //.....................................//

  }//end constructor
  
}//end class Swing13