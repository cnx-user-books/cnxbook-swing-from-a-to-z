/*File Swing19
Rev 3/30/00
Copyright 2000, R.G.Baldwin

incomplete

Illustrates the use of the BorderFactory
class for nesting of CompoundBorder 
objects.  This program creates and 
displays two different border styles. 

Borders created using BorderFactory are
shared among objects.  That is the advantage
of using the factory method.

Also illustrates specifying the highlight
and shadow colors for a BevelBorder and, 
just for fun, shows that simply reversing
the two (making the shadow light and the
highlight dark) reverses the optical
illusion and causes a LOWERED 3-D component
to appear to be RAISED.  This illustrates
how we have become conditioned to having
the light source at the upper left.  The
reversal of the two colors would be correct
for a LOWERED 3-D component if the light 
source were at the bottom right.

Tested using JDK 1.2.2 under WinNT 4.0 WkStn
********************************************/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class Swing19 extends JFrame{

  //---------------------------------------//  

  public static void main(String args[]) {
      new Swing19();
  }//end main()
  //---------------------------------------//
  
  //The purpose of this method is to create
  // and return an opaque pink JLabel with
  // a border.  The text content of the 
  // lable is provided as the first
  // parameter.  The border type is provided
  // as the second parameter.  When the
  // label is displayed, the left and top
  // insets are displayed following the 
  // text content of the label.
  JLabel makeLabel(
           String content,Border borderType){
      
    JLabel label = new JLabel();
    label.setBorder(borderType);
    label.setOpaque(true);
    label.setBackground(Color.pink);

    label.setText(content + "," 
    +label.getInsets().left + ","
    +label.getInsets().top);
      
    return label;
      
  }//end makeLabel()
  //---------------------------------------//
  
  Swing19(){//constructor
    
    getContentPane().setLayout(
                           new FlowLayout());

    CompoundBorder theBorder = 
     BorderFactory.createCompoundBorder(
      BorderFactory.createBevelBorder(
       BevelBorder.LOWERED,Color.black,
                               Color.yellow),
        BorderFactory.createCompoundBorder(
         BorderFactory.createMatteBorder(
          19,19,19,19,Color.blue),
           BorderFactory.createEmptyBorder(
                                  5,5,5,5)));

    getContentPane().add(makeLabel(
         "Nested CompoundBorder",theBorder));
    
    theBorder = 
     BorderFactory.createCompoundBorder(
      BorderFactory.createBevelBorder(
       BevelBorder.RAISED,Color.yellow,
                               Color.black),
        BorderFactory.createCompoundBorder(
         BorderFactory.createMatteBorder(
          19,19,19,19,Color.blue),
           BorderFactory.createEmptyBorder(
                                  5,5,5,5)));

    getContentPane().add(makeLabel(
         "Nested CompoundBorder",theBorder));

    setTitle("Copyright 2000, R.G.Baldwin");
    setSize(329,200);
    setVisible(true);
    
    //.....................................//
    //Anonymous inner terminator class
    this.addWindowListener(
      new WindowAdapter(){
        public void windowClosing(
                              WindowEvent e){
          System.exit(0);
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
    //.....................................//

  }//end constructor
  
}//end class Swing19