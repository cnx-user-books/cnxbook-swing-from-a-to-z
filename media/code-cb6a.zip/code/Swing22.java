/*File Swing22.java Rev 8/17/00
Copyright 2000, R.G.Baldwin

This is the first in a series of programs
designed to illustrate the use of focus in
Swing.

However, this particular program is not about
Swing.  Rather, it illustrates how the focus
traverses its cycle among AWT components.  
This will be contrasted with the manner in
which the focus traverses its cycle in 
Swing.

Illustrates two important aspects of AWT
focus handling:
  
First, the order of focus traversal is the
order in which the components are placed in
the container.

Second, it is possible to request that focus
be moved to a specific component by invoking
the requestFocus() method on that component.
Like Swing, the default is for the first 
component placed in the container to have 
the focus when the program starts running.  
In this case, that would be the East Button.
A ComponentEvent handler requests focus on 
the North Button immediately after the GUI 
is made visible, which causes the focus to 
reside on the North Button by the time the 
GUI is available to the user.

Thus, the order of focus traversal is 
North, Center, East, West, South, and back
to North.  Focus traversal can be observed
by repeatedly pressing the Tab key.  
Repeatedly pressing Shift-Tab will reverse
the order of focus traversal among the
components.

There are no event handlers registered on 
the five buttons placed in the Frame.  
However, a component listener is registered
on the Frame to invoke requestFocus()on the
North button when the Frame becomes visible.
(You can only request focus on a component
after it becomes visible.)

Tested using JDK 1.2.2 under WinNT 4.0 WkStn
********************************************/

import java.awt.*;
import java.awt.event.*;

class Swing22 extends Frame{
  Button northBtn = new Button("North");
  
  public static void main(String args[]) {
    new Swing22();
  }//end main()
  //---------------------------------------//
  
  Swing22(){//Constructor
    add(new Button("East"),"East");
    add(new Button("West"),"West");
    add(new Button("South"),"South");
    add(northBtn,"North");
    add(new Button("Center"),"Center");
    
    setTitle("Copyright 2000, R.G.Baldwin");
    setSize(300,100);

    //Register component listener to request
    // focus on the north Button after the
    // Frame becomes visible.
    //.....................................//
    this.addComponentListener(
      new ComponentAdapter(){
        public void componentShown(
                           ComponentEvent e){
          northBtn.requestFocus();
        }//end componentShown
      }//end ComponentAdapter
    );//end addComponentListener
    //.....................................//

    //Make the Frame visible
    setVisible(true);

    //.....................................//
    //Anonymous inner terminator class
    this.addWindowListener(
      new WindowAdapter(){
        public void windowClosing(
                              WindowEvent e){
          System.exit(0);
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
    //.....................................//

  }//end constructor
}//end class Swing22