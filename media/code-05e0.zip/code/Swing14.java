/*File Swing14
Rev 3/30/00
Copyright 2000, R.G.Baldwin

Illustrates nesting of CompoundBorder 
objects.  This program creates and 
displays two different border styles
constructed by nesting CompoundBorder
objects. 


Tested using JDK 1.2.2 under WinNT 4.0 WkStn
********************************************/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class Swing14 extends JFrame{

  //---------------------------------------//  

  public static void main(String args[]) {
      new Swing14();
  }//end main()
  //---------------------------------------//
  
  //The purpose of this method is to create
  // and return an opaque pink JLabel with
  // a border.  The text content of the 
  // lable is provided as the first
  // parameter.  The border type is provided
  // as the second parameter.  When the
  // label is displayed, the left and top
  // insets are displayed following the 
  // text content of the label.
  JLabel makeLabel(
           String content,Border borderType){
      
    JLabel label = new JLabel();
    label.setBorder(borderType);
    label.setOpaque(true);
    label.setBackground(Color.pink);

    label.setText(content + "," 
    +label.getInsets().left + ","
    +label.getInsets().top);
      
    return label;
      
  }//end makeLabel()
  //---------------------------------------//
  
  Swing14(){//constructor
    
    getContentPane().setLayout(
                           new FlowLayout());
                           
    CompoundBorder theBorder = 
      new CompoundBorder(
        new BevelBorder(BevelBorder.LOWERED),
          new CompoundBorder(
            new MatteBorder(19,19,19,19,
              Color.blue),new EmptyBorder(
                                  5,5,5,5)));

    getContentPane().add(makeLabel(
         "Nested CompoundBorder",theBorder));
    
    theBorder = new CompoundBorder(
      new BevelBorder(BevelBorder.RAISED),
        new CompoundBorder(new MatteBorder(
          19,19,19,19,Color.blue),
                  new EmptyBorder(5,5,5,5)));

    getContentPane().add(makeLabel(
         "Nested CompoundBorder",theBorder));

    setTitle("Copyright 2000, R.G.Baldwin");
    setSize(329,200);
    setVisible(true);
    
    //.....................................//
    //Anonymous inner terminator class
    this.addWindowListener(
      new WindowAdapter(){
        public void windowClosing(
                              WindowEvent e){
          System.exit(0);
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
    //.....................................//

  }//end constructor
  
}//end class Swing14