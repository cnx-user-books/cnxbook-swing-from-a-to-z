//Note:  This program fails to list some of the
// focus properties of a JButton defined by is
// methods such as isFocusable.
//See Introspect04 for more info.

//3456789012345678901234567890123456789

/*File Introspect03.java 
Copyright 2000, R.G.Baldwin

Produces a GUI that displays 
inheritance, interfaces, properties,
events, and methods about components,
or about any class that is a bean.

Requires JDK 1.3 or later.  Otherwise,
must service the windowClosing event 
to terminate the program.
Tested using JDK 1.3 under WinNT.  
**************************************/
import java.io.*;
import java.beans.*;
import java.lang.reflect.*;
import java.util.*;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;

public class Introspect03 
                        extends JFrame{
  private JLabel errors = 
      new JLabel("Errors appear here");
  private JPanel outputPanel = 
                          new JPanel();
  private JPanel inputPanel = 
                          new JPanel();
  private JTextField targetClass = 
                    new JTextField(14);
  private JTextField ceilingClass = 
                    new JTextField(14);
  private JButton okButton = 
                     new JButton("OK");
  
  private JTextArea inher = new 
       JTextArea("INHERITANCE\n",8,17);
  private JScrollPane inherPane = 
                new JScrollPane(inher);
  private JTextArea intfcs = new 
        JTextArea("INTERFACES\n",8,17);
  private JScrollPane intfcsPane = 
               new JScrollPane(intfcs);
  private JTextArea props = new 
        JTextArea("PROPERTIES\n",8,17);
  private JScrollPane propsPane = 
                new JScrollPane(props);
  private JTextArea events = 
        new JTextArea("EVENTS\n",8,17);
  private JScrollPane eventsPane = 
               new JScrollPane(events);
  private JTextArea methods = 
       new JTextArea("METHODS\n",8,17);
  private JScrollPane methodsPane = 
              new JScrollPane(methods);
  
  private BeanInfo beanInfo;
  private Vector intfcsVector = 
                          new Vector();
  
  public static void main(
                        String args[]){
    new Introspect03();
  }//end main
  
  public Introspect03() {//constructor
    //This require JDK 1.3 or later.
    // Otherwise service windowClosing
    // event to terminate the program.
    setDefaultCloseOperation(
                 JFrame.EXIT_ON_CLOSE);

    outputPanel.setBackground(
                          Color.green);
    inputPanel.setBackground(
                         Color.yellow);

    outputPanel.add(inherPane);
    outputPanel.add(intfcsPane);
    outputPanel.add(propsPane);
    outputPanel.add(eventsPane);
    outputPanel.add(methodsPane);
    
    //Set some default values
    targetClass.setText(
                "javax.swing.JButton");
    ceilingClass.setText(
                   "java.lang.Object");

    inputPanel.add(targetClass);
    inputPanel.add(ceilingClass);
    inputPanel.add(okButton);

    getContentPane().add(
                       errors,"North");
    getContentPane().add(
                 outputPanel,"Center");
    getContentPane().add(
                   inputPanel,"South");
    setResizable(false);
    setSize(400,520);
    setTitle(
        "Copyright 2000, R.G.Baldwin");
    setVisible(true);

    //Anonymous inner class to provide
    // event handler for okButton
    okButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(
                        ActionEvent e){
          errors.setText(
                 "Errors appear here");
          inher.setText(
                      "INHERITANCE\n");
          intfcs.setText(
                       "INTERFACES\n");
          props.setText(
                       "PROPERTIES\n");
          events.setText(
                           "EVENTS\n");
          methods.setText("METHODS\n");
          try{
            Class targetClassObject = 
              Class.forName(
                targetClass.getText());
            doInheritance();
            doInterfaces();
            beanInfo = Introspector.
                   getBeanInfo(
                     targetClassObject,
                       Class.forName(
                         ceilingClass.
                           getText()));
            doProperties();
            doEvents();
            doMethods();
          }catch(Exception ex){
                    errors.setText(
                       ex.toString());}
        }//end actionPerformed
       }//end ActionListener
     );//end addActionListener
      
  }//end constructor
  
  
  void doInheritance() 
         throws ClassNotFoundException{
    //Get and display inheritance
    // hierarchy
    Vector inherVector = new Vector();
    String theClass = targetClass.
                             getText();
    Class theClassObj = null;
    Class theSuperClass = null;
    while(!(theClass.equals(
                 "java.lang.Object"))){
      inherVector.add(theClass);
      theClassObj = Class.forName(
                             theClass);
      theSuperClass = theClassObj.
                       getSuperclass();
      
      //Get and save interfaces to be
      // used later
      if(theClassObj.getInterfaces() 
                              != null){
        intfcsVector.add(theClassObj.
                      getInterfaces());
      }//end if
      
              
      theClass = theSuperClass.
                             getName();
               
    }//end while loop
    inherVector.add(
                   "java.lang.Object");
                   
    //Display vector contents in
    // reverse order
    for(int i = 0; 
           i < inherVector.size();i++){
      inher.append(
       ((String)inherVector.elementAt(
         inherVector.size() - (i+1))));
      inher.append("\n");
    }//end for loop
  }//end doInheritance
  
  
  void doInterfaces(){
    Vector interfaceNameVector = 
                          new Vector();
    //Interface information was stored
    // in intfcsVector earlier.
    for(int i = 0; 
          i < intfcsVector.size();i++){
      Class[] interfaceSet = 
                 (Class[])intfcsVector.
                          elementAt(i);
      for(int j = 0; 
          j < interfaceSet.length;j++){
        interfaceNameVector.add(
            interfaceSet[j].getName());                        
                        
                        
      }//end for loop on j
    }//end for loop on i

    Object[] interfaceNameArray = 
         interfaceNameVector.toArray();
    Arrays.sort(interfaceNameArray);

    if(interfaceNameArray.length > 0){ 
      intfcs.append(
                 interfaceNameArray[0].
                           toString());
      intfcs.append("\n");
    }//end if

    for(int i = 1;
         i < interfaceNameArray.length;
                                  i++){
      //Eliminate dup interface names
      if(!(interfaceNameArray[i].
          equals(
            interfaceNameArray[i-1]))){
        intfcs.append(
                 interfaceNameArray[i].
                           toString());
        intfcs.append("\n");
      }//end if
    }//end for loop
  }//end doInterfaces
  
  
  void doProperties(){
    Vector propVector = new Vector();
    PropertyDescriptor[] propDescrip = 
            beanInfo.
              getPropertyDescriptors();
    for (int i = 0; 
         i < propDescrip.length; i++) {
      PropClass propObj = 
                       new PropClass();
      propObj.setName(propDescrip[i].
                            getName());
      propObj.setType("" +
                  propDescrip[i].
                    getPropertyType());
      propVector.add(propObj);
    }//end for-loop

    Object[] propArray = propVector.
                             toArray();
    Arrays.sort(
            propArray,new PropClass());
    for(int i = 0; 
             i < propArray.length;i++){
      props.append(propArray[i].
                           toString());
      props.append("\n");
    }//end for loop
  }//end doProperties
  
  
  void doEvents(){
    Vector eventVector = new Vector();
    EventSetDescriptor[] evSetDescrip = 
            beanInfo.
              getEventSetDescriptors();
    for (int i = 0; 
         i < evSetDescrip.length; i++){
      EventClass eventObj = 
                      new EventClass();
      eventObj.setName(evSetDescrip[i].
                            getName());
      MethodDescriptor[] methDescrip = 
        evSetDescrip[i].
        getListenerMethodDescriptors();
      for (int j = 0;
         j < methDescrip.length; j++) {
        eventObj.setListenerMethod(
             methDescrip[j].getName());
      }//end for-loop
      eventVector.add(eventObj);
    }//end for-loop

    Object[] eventArray = eventVector.
                             toArray();
    Arrays.sort(
          eventArray,new EventClass());
    for(int i = 0;
            i < eventArray.length;i++){
      events.append(eventArray[i].
                           toString());
      events.append("\n");
    }//end for loop
  }//end doEvents
  
  
  void doMethods(){
    Vector methVector = new Vector();
    MethodDescriptor[] methDescrip = 
       beanInfo.getMethodDescriptors();
    for (int i = 0; 
         i < methDescrip.length; i++) {
        methVector.add(
             methDescrip[i].getName());
    }//end for-loop
    
    Object[] methodArray = 
                  methVector.toArray();
    Arrays.sort(methodArray);

    if(methodArray.length > 0){ 
      methods.append(
            methodArray[0].toString());
      methods.append("\n");
    }//end if

    for(int i = 1;
           i < methodArray.length;i++){
      //Eliminate dup method names
      if(!(methodArray[i].equals(
                   methodArray[i-1]))){
        methods.append(
            methodArray[i].toString());
        methods.append("\n");
      }//end if
    }//end for loop
  }//end doMethods
//===================================//

//This inner class is used to
// encapsulate name and type
// information about properties.  It
// also serves as a class from which a
// Comparator object can be
// instantiated to assist in sorting
// by name.
class PropClass implements Comparator{
  private String name;
  private String type;
  
  public void setName(String name){
    this.name = name;
  }//end setName
  
  public String getName(){
    return name;
  }//end getName
  
  public void setType(String type){
    this.type = type;
  }//end setType
  
  public String toString(){
    return(name + "\n  " + type);
  }//end toString
  
  public int compare(
                 Object o1, Object o2){
    return ((PropClass)o1).getName().
           toUpperCase().compareTo(
             ((PropClass)o2).getName().
                        toUpperCase());
  }//end compare
  
  public boolean equals(Object obj){
    return this.getName().equals(
           ((PropClass)obj).getName());
  }//end equals
}//end class PropClass
//===================================//

//This inner class is used to
// encapsulate name and handler
// information about events.  It also
// serves as a class from which a
// Comparator object can be
// instantiated to assist in sorting
// by name.
class EventClass implements Comparator{
  private String name;
  private Vector lstnrMethods = 
                          new Vector();
  
  public void setName(String name){
    this.name = name;
  }//end setName
  
  public String getName(){
    return name;
  }//end getName
  
  public void setListenerMethod(
                   String lstnrMethod){
    lstnrMethods.add(lstnrMethod);
  }//end setType
  
  public String toString(){
    String theString = name;

    for(int i = 0; 
          i < lstnrMethods.size();i++){
      theString = theString + "\n  " + 
             lstnrMethods.elementAt(i);
    }//end for loop

    return theString;
  }//end toString
  
  public int compare(
                 Object o1, Object o2){
    return ((EventClass)o1).getName().
          toUpperCase().compareTo(
            ((EventClass)o2).getName().
                        toUpperCase());
  }//end compare
  
  public boolean equals(Object obj){
    return this.getName().equals(
          ((EventClass)obj).getName());
  }//end equals
}//end EventClass inner class
  
}//end controlling class Introspect03