/*File Swing11
Rev 3/26/00
Copyright 2000, R.G.Baldwin

Illustrates very simple use of JButton,
JTextField, and JLabel.

Tested using JDK 1.2.2 under WinNT 4.0 WkStn
********************************************/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;//jdk 1.2 version

class Swing11 extends JFrame 
                   implements ActionListener{
  JButton jButton = new JButton("JButton");
  JTextField jTextField = new JTextField(
                               "JTextField");
  JLabel jLabel = new JLabel("JLabel");  
  
  //---------------------------------------//
  Swing11(){//constructor
    jButton.addActionListener(this);  
    jTextField.addActionListener(this);
    
    getContentPane().setLayout(
                           new FlowLayout());
    getContentPane().add(jButton);
    getContentPane().add(jTextField);
    getContentPane().add(jLabel);
    setTitle("Copyright 2000, R.G.Baldwin");
    setSize(300,100);
    setVisible(true);
    
    //.....................................//
    //Anonymous inner terminator class
    this.addWindowListener(
      new WindowAdapter(){
        public void windowClosing(
                              WindowEvent e){
          System.exit(0);
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor

  //---------------------------------------//
  public static void main(String args[]) {
      new Swing11();
  }//end main()

  //---------------------------------------//
  public void actionPerformed(ActionEvent e){
    jLabel.setText(e.getActionCommand());
  }//end actionPerformed
  //---------------------------------------//
}//end class Swing11


