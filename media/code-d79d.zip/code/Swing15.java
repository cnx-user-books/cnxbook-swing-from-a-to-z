/*File Swing15
Rev 3/30/00
Copyright 2000, R.G.Baldwin

Illustrates use of setAlignmentY to adjust
the vertical position of some buttons in a 
Box container.  Also illustrates the use 
of a Box container.

Tested using JDK 1.2.2 under WinNT 4.0 WkStn
********************************************/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class Swing15 extends JFrame{

  //---------------------------------------//

  public static void main(String args[]) {
      new Swing15();
  }//end main()
  //---------------------------------------//
  
  Swing15(){//constructor

    //Set for center alignment in the 
    // contentPane  
    getContentPane().setLayout(
          new FlowLayout(FlowLayout.CENTER));    

    //Instantiate a new horizontal Box
    // object.  Could also use the method
    // named createHorizontalBox()
    Box aBox = new Box(BoxLayout.X_AXIS);

    //Add the Box to the contentPane
    getContentPane().add(aBox);
    
    //Instantiate three JButton objects,
    // make them green, and set their
    // vertical alignment.  Note that the
    // default vertical alignment is 0.5f.
    JButton but1 = new JButton("but1");
    but1.setAlignmentY(0.25f);
    but1.setBackground(Color.green);
    
    JButton but2 = new JButton("but2");
    but2.setBackground(Color.green);
        
    JButton but3 = new JButton("but3");
    but3.setAlignmentY(0.75f);
    but3.setBackground(Color.green);
    
    //Instantiate two JLabel objects  Use a
    // compound border to make them taller
    // than the buttons.  Color them yellow.
    JLabel lab1 = new JLabel("lab1");
    lab1.setBorder(new CompoundBorder(
         new EtchedBorder(),new EmptyBorder(
                                20,2,20,2)));
    lab1.setBackground(Color.yellow);
    lab1.setOpaque(true);
    
    JLabel lab2 = new JLabel("lab2");
    lab2.setBorder(new CompoundBorder(
         new EtchedBorder(),new EmptyBorder(
                                20,2,20,2)));
    lab2.setBackground(Color.yellow);
    lab2.setOpaque(true);

    //Add the buttons and the labels to the
    // Box.
    aBox.add(but1);
    aBox.add(lab1);
    aBox.add(but2);
    aBox.add(lab2);
    aBox.add(but3);


    setTitle("Copyright 2000, R.G.Baldwin");
    setSize(329,100);
    setVisible(true);
    
    //.....................................//
    //Anonymous inner terminator class
    this.addWindowListener(
      new WindowAdapter(){
        public void windowClosing(
                              WindowEvent e){
          System.exit(0);
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
    //.....................................//

  }//end constructor
  
}//end class Swing15