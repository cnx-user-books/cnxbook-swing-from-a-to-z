/*File Swing12
Rev 3/28/00
Copyright 2000, R.G.Baldwin

Illustrates the manipulation of several
properties of a JLabel and a JButton under
program control. Primary properties 
manipulated are:
  
opaque (transparency)  
preferredSize

Other properties manipulated are:
    
layout
background
foreground
title
size
visible
text
contentPane
source

Tested using JDK 1.2.2 under WinNT 4.0 WkStn
********************************************/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;//jdk 1.2 version

class Swing12 extends JFrame{
  JButton button = new JButton(
                   "Make Label Transparent");
  JLabel label = new JLabel(
    "A JLabel component");
  //---------------------------------------//  

  public static void main(String args[]) {
      new Swing12();
  }//end main()
  //---------------------------------------//

  Swing12(){//constructor
    
    getContentPane().setLayout(
                           new FlowLayout());
    label.setBackground(Color.yellow);
    label.setForeground(Color.blue);
    //Default is transparent
    label.setOpaque(true);
    
    getContentPane().add(button);
    getContentPane().add(label);
    setTitle("Copyright 2000, R.G.Baldwin");
    setSize(329,100);
    setVisible(true);
   
    //Cause the button to stay the same
    // size when its text changes
    button.setPreferredSize(
                           button.getSize());
    
    //.....................................//
    //Anonymous action listener class
    button.addActionListener(
      new ActionListener(){
        public void actionPerformed(
                             ActionEvent e){
          if(label.isOpaque()){
            label.setOpaque(false);
            label.repaint();//render it
            ((JButton)e.getSource()).
               setText("Make Label Opaque");
          }//end if
          else{//if it is not opaque
            label.setOpaque(true);
            label.repaint();//render it
            ((JButton)e.getSource()).
               setText(
                  "Make Label Transparent");
          }//end else
        }//end actionPerformed
      }//end ActionListener
    );//end addActionListener
    
    //.....................................//
    //Anonymous inner terminator class
    this.addWindowListener(
      new WindowAdapter(){
        public void windowClosing(
                              WindowEvent e){
          System.exit(0);
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor

  //---------------------------------------//
}//end class Swing12