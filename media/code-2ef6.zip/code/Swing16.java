/*File Swing16
Rev 3/30/00
Copyright 2000, R.G.Baldwin

Illustrates use of glue and struts to control
the separation between components.  In order
to see the effect of using glue, you must
manually resize the JFrame object to make 
it larger and smaller.

Tested using JDK 1.2.2 under WinNT 4.0 WkStn
********************************************/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

class Swing16 extends JFrame{

  public static void main(String args[]) {
      new Swing16();
  }//end main()
  //---------------------------------------//
  
  Swing16(){//constructor

    //Instantiate a new horizontal Box
    // object.  Could also use the 
    // constructor
    // new Box(BoxLayout.X_AXIS);
    Box aBox = Box.createHorizontalBox();

    //Add the Box to the contentPane
    getContentPane().add(aBox);
    
    //Instantiate three JButton objects,
    // make them green.
    JButton but1 = new JButton("but1");
    but1.setBackground(Color.green);
    
    JButton but2 = new JButton("but2");
    but2.setBackground(Color.green);
        
    JButton but3 = new JButton("but3");
    but3.setBackground(Color.green);
    
    //Instantiate two JLabel objects  Use a
    // compound border to make them taller
    // than the buttons.  Color them yellow.
    JLabel lab1 = new JLabel("lab1");
    lab1.setBorder(
        new CompoundBorder(
            new EtchedBorder(),
                new EmptyBorder(20,2,20,2)));
    lab1.setBackground(Color.yellow);
    lab1.setOpaque(true);
    
    JLabel lab2 = new JLabel("lab2");
    lab2.setBorder(
        new CompoundBorder(
            new EtchedBorder(),
                new EmptyBorder(20,2,20,2)));
    lab2.setBackground(Color.yellow);
    lab2.setOpaque(true);

    //Add the buttons and the labels to the
    // Box.  Insert glue between the labels
    // and the buttons on each end.  Insert
    // horizontal struts between each of the 
    // components to control the minimum
    // spacing between them.
    aBox.add(but1);
    aBox.add(Box.createGlue());
    aBox.add(Box.createHorizontalStrut(3));
    aBox.add(lab1);
    aBox.add(Box.createHorizontalStrut(3));
    aBox.add(but2);
    aBox.add(Box.createHorizontalStrut(3));
    aBox.add(lab2);
    aBox.add(Box.createHorizontalStrut(3));

    aBox.add(Box.createGlue());
    aBox.add(but3);

    setTitle("Copyright 2000, R.G.Baldwin");
    //Pack the JFrame down around the 
    // components
    pack();
    setVisible(true);
    
    //.....................................//
    //Anonymous inner terminator class
    this.addWindowListener(
      new WindowAdapter(){
        public void windowClosing(
                              WindowEvent e){
          System.exit(0);
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
    //.....................................//

  }//end constructor
  
}//end class Swing16